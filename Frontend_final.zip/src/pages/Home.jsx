import React, { useEffect, useState } from 'react'
import Slider from "../component/Slider"
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import VidGrid from '../component/VidGrid';

const Home = () => {
  const [vidList, setVidList] = useState([]);
  const [error,setError] = useState(null)
  useEffect(()=>{
    const token = localStorage.getItem('token');
    const authHeader = "Bearer " + token;
    fetch(`${process.env.REACT_APP_BASE_URL}/videos`,
    {
      headers:{
        'Content-Type': 'application/json',
        'Authorization': authHeader
      }
    })
    .then(async response=>{
      const {data} = await response.json();
      setVidList(data);
    })
    .catch(err=>{
      setError(err.message);
      console.error(err)
    });
  },[])

  if(error){
    return (
      <div className='text-4xl text-red-700 m-auto'>
        { error }
      </div>
    )
  }

  return (
    <div>
      <Slider />
      <VidGrid data = {vidList}/>
    </div>
  )
}

export default Home
